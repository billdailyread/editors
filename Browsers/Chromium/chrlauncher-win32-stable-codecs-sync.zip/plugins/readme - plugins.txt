About Flash plugin, put in this folder:
- pepflashplayer.dll